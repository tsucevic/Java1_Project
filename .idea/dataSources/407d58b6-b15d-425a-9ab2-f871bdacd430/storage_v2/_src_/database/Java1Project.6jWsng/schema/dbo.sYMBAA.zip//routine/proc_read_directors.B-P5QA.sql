create proc proc_read_directors
as
    begin
        select D.*, P.FullName
        from People P
                 inner join Directors D on P.IDPerson = D.PersonID
    end
go

