create proc proc_delete_actor @IDActor int
as
    begin
        delete
        from MovieActor
        where ActorID = @IDActor
        delete
        from Actors
        where IDActor = @IDActor
    end
go

