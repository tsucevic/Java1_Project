create proc proc_reset_to_default
as
    begin
        -- datagrip was being dumb
        delete from Users where null is null
        delete from Roles where null is null
        delete from MovieActor where null is null
        delete from Actors where null is null
        delete from Movies where null is null
        delete from Directors where null is null
        delete from People where null is null
        exec proc_init_default_settings
    end
go

