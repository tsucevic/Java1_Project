create proc proc_create_movie_actor
    @MovieID int,
    @ActorID int
as
    begin
        insert into MovieActor
        values (@MovieID, @ActorID)
    end
go

