create proc proc_read_movies
as
    begin
        select IDMovie,
               Title,
               OriginalTitle,
               DescriptionHTML,
               Length,
               Genre,
               PosterLink,
               TrailerLink,
               Link,
               GUID,
               StartsPlaying
        from Movies
    end
go

