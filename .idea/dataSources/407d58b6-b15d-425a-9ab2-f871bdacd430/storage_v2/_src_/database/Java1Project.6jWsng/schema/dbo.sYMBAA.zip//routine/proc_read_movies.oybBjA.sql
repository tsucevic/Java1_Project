create proc proc_read_movies
as
    begin
        select IDMovie,
               Title,
               OriginalTitle,
               FullName as Director,
               DescriptionHTML,
               Length,
               Genre,
               PosterLink,
               TrailerLink,
               Link,
               GUID,
               StartsPlaying
        from Movies as M
            inner join Directors D on D.IDDirector = M.DirectorID
            inner join People P on D.PersonID = P.IDPerson
    end
go

