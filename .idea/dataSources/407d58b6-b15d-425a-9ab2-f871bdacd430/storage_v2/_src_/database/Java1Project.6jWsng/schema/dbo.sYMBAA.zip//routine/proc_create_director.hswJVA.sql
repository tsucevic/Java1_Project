create proc proc_create_director
    @Name nvarchar(128),
    @DirectorID int output
as
    begin
        if exists(select IDPerson
                  from People
                  where FullName = @Name)
            begin
                declare @PersonID int = (select IDPerson
                                         from People
                                         where FullName = @Name)
                if exists(select IDDirector from Directors where PersonID = @PersonID)
                    begin
                        set @DirectorID = (select IDDirector from Directors where PersonID = @PersonID)
                    end
                else
                    begin
                        insert into Directors (PersonID)
                        values (@PersonID)
                        set @DirectorID = scope_identity()
                    end
            end
        else
            begin
                insert into People
                values (@Name)
                insert into Directors (PersonID)
                values (scope_identity())
                set @DirectorID = scope_identity()
            end

    end
go

