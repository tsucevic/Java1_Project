create proc proc_delete_movie_actor
    @MovieID int,
    @ActorID int
as
    begin
        delete
        from MovieActor
        where MovieID = @MovieID
          and ActorID = @ActorID
    end
go

