create proc proc_update_director
    @IDDirector int,
    @FullName nvarchar(128),
    @Alias nvarchar(128)
as
    begin
        update People
        set FullName = @FullName
        where IDPerson = (select PersonID from Directors where IDDirector = @IDDirector)
        if @Alias not like null
            begin
                update Directors
                set Alias = @Alias
                where IDDirector = @IDDirector
            end
    end
go

