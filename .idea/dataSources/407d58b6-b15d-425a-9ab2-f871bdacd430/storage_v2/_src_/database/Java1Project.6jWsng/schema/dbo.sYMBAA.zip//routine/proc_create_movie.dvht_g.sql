create proc proc_create_movie
    @Title nvarchar(256),
    @OriginalTitle nvarchar(256),
    @DescriptionHTML nvarchar(4000),
    @Length int,
    @Genre nvarchar(64),
    @PosterLink nvarchar(512),
    @TrailerLink nvarchar(512),
    @Link nvarchar(512),
    @GUID nvarchar(512),
    @StartsPlaying date,
    @MovieID int output
as
    begin
        insert into Movies
        values (@Title,
                @OriginalTitle,
                @DescriptionHTML,
                @Length,
                @Genre,
                @PosterLink,
                @TrailerLink,
                @Link,
                @GUID,
                @StartsPlaying)
        set @MovieID = scope_identity()
    end
go

