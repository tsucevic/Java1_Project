create proc proc_update_movie
    @IDMovie int,
    @Title nvarchar(256),
    @OriginalTitle nvarchar(256),
    @DescriptionHTML nvarchar(4000),
    @Length int,
    @Genre nvarchar(64),
    @PosterLink nvarchar(512),
    @TrailerLink nvarchar(512),
    @Link nvarchar(512),
    @GUID nvarchar(512),
    @StartsPlaying date
as
    begin
        update Movies
            set Title           = @Title,
                OriginalTitle   = @OriginalTitle,
                DescriptionHTML = @DescriptionHTML,
                Length          = @Length,
                Genre           = @Genre,
                PosterLink      = @PosterLink,
                TrailerLink     = @TrailerLink,
                Link            = @Link,
                GUID            = @GUID,
                StartsPlaying   = @StartsPlaying
        where IDMovie = @IDMovie
    end
go

