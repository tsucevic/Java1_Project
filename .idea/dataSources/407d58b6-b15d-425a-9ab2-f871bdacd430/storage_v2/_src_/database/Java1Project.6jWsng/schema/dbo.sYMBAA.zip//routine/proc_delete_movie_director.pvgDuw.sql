create proc proc_delete_movie_director
    @MovieID int,
    @DirectorID int
as
    begin
        delete
        from MovieDirector
        where MovieID = @MovieID
          and DirectorID = @DirectorID
    end
go

