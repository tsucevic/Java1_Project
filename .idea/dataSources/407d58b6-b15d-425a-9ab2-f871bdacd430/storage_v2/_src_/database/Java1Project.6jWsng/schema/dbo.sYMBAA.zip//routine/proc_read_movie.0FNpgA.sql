create proc proc_read_movie @IDMovie int
as
    begin
        select IDMovie,
               Title,
               OriginalTitle,
               DescriptionHTML,
               Length,
               Genre,
               PosterLink,
               TrailerLink,
               Link,
               GUID,
               StartsPlaying
        from Movies
        where IDMovie = @IDMovie
    end
go

