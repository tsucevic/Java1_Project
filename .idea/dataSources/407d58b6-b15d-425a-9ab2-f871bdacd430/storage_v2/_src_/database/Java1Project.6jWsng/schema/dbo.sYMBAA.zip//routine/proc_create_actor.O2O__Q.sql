create proc proc_create_actor
    @Name nvarchar(128),
    @ActorID int output
as
    begin
        if exists(select IDPerson
                  from People
                  where FullName = @Name)
            begin
                declare @PersonID int = (select IDPerson
                                         from People
                                         where FullName = @Name)
                if exists(select IDActor from Actors where PersonID = @PersonID)
                    begin
                        set @ActorID = (select IDActor from Actors where PersonID = @PersonID)
                    end
                else
                    begin
                        insert into Actors (PersonID)
                        values (@PersonID)
                        set @ActorID = scope_identity()
                    end
            end
        else
            begin
                insert into People
                values (@Name)
                insert into Actors (PersonID)
                values (scope_identity())
                set @ActorID = scope_identity()
            end

    end
go

