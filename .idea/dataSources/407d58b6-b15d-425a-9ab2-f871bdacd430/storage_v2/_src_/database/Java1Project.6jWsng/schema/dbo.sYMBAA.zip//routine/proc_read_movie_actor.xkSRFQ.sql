create proc proc_read_movie_actor @MovieID int
as
    begin
        select A.*, P.FullName
        from Actors A
                 inner join People P on P.IDPerson = A.PersonID
                 inner join MovieActor MA on A.IDActor = MA.ActorID
        where MovieID = @MovieID
    end
go

