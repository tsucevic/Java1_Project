create proc proc_init_default_settings
as
    begin
        if not exists(select * from Roles where Title = 'Admin' or Title = 'User')
            begin
                insert into Roles
                values ('Admin', 100),
                       ('User', 50)
            end
        if not exists(select * from Users where Username = 'Admin')
            begin
                insert into Users
                values ((select IDRole from Roles where Title = 'Admin'), 'Admin', '1234')
            end
    end
go

