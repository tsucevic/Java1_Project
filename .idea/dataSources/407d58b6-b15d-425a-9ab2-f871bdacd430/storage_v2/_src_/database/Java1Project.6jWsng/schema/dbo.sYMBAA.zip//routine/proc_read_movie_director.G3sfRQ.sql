create proc proc_read_movie_director @MovieID int
as
    begin
        select A.*, P.FullName
        from Directors A
                 inner join People P on P.IDPerson = A.PersonID
                 inner join MovieDirector MA on A.IDDirector = MA.DirectorID
        where MovieID = @MovieID
    end
go

