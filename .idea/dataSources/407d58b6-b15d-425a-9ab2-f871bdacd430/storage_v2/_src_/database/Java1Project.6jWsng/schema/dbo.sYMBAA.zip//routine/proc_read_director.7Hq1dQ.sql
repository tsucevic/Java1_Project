create proc proc_read_director @IDDirector int
as
    begin
        select D.*, P.FullName
        from Directors D
                 inner join People P on D.PersonID = P.IDPerson
        where IDDirector = @IDDirector
    end
go

