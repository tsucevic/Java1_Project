create proc proc_read_actor @IDActor int
as
    begin
        select A.*, P.FullName
        from Actors A
                 inner join People P on P.IDPerson = A.PersonID
        where IDActor = @IDActor
    end
go

