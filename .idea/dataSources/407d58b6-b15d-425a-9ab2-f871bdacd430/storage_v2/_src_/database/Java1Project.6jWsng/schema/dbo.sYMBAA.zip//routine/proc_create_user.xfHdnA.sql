create proc proc_create_user
    @Username nvarchar(16),
    @Password nvarchar(128),
    @UserID int output
as
    begin
        insert into Users
        values (@Username,@Password,(select top 1 IDRole from Roles where Title = 'User'))
        set @UserID = scope_identity()
    end
go

