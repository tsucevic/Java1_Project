create proc proc_create_movie_director
    @MovieID int,
    @DirectorID int
as
    begin
        insert into MovieDirector
        values (@MovieID, @DirectorID)
    end
go

