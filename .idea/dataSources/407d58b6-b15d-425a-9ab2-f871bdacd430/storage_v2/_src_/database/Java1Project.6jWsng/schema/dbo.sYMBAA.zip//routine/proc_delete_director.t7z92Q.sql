create proc proc_delete_director @IDDirector int
as
    begin
        delete
        from MovieDirector
        where DirectorID = @IDDirector
        delete
        from Directors
        where IDDirector = @IDDirector
    end
go

