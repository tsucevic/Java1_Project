create proc proc_delete_movie @IDMovie int
as
    begin
        delete from Movies where IDMovie = @IDMovie
    end
go

