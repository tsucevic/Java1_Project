create proc proc_get_user @Username nvarchar(16)
as
    begin
        select IDUser, Username, Password, Title as Role, AccessLevel
        from Users U
            inner join Roles R2 on R2.IDRole = U.RoleID
        where Username like @Username
    end
go

