create proc proc_update_actor
    @IDActor int,
    @FullName nvarchar(128),
    @Alias nvarchar(128) = null
as
    begin
        update People
        set FullName = @FullName
        where IDPerson = (select PersonID from Actors where IDActor = @IDActor)
        if @Alias not like null
            begin
                update Actors
                set Alias = @Alias
                where IDActor = @IDActor
            end
    end
go

