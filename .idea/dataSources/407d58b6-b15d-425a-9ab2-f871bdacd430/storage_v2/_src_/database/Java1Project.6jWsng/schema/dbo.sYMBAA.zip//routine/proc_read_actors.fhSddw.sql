create proc proc_read_actors
as
    begin
        select A.*, P.FullName
        from People P
                 inner join Actors A on P.IDPerson = A.PersonID
    end
go

